# Rust Programming For Beginners Activity Files
This is the repository containing the source activity files for the [Rust Programming For Beginners](https://www.udemy.com/course/rust-coding-for-beginners/?referralCode=21DF1FD210891286AE0E) course hosted on Udemy.

## Solutions
To view solutions for the activities, checkout the `solutions` branch by running `git checkout solutions` after cloning this repo.